/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelo.Gerente;


/**
 *
 * @author jrafael
 */
public class LoginCon {

    public Gerente consultarLogin(String cpf) {
        return null;
        // Código para consultar uma única tupla
        /*Gerente gerente = null;
        try {
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getCon().prepareStatement("SELECT * FROM conta WHERE cpf= ?");
            ps.setString(1, cpf);
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    gerente = new Gerente();
                    gerente.setCpf(rs.getInt("cpf"));
                    gerente.setLogin(rs.getInt("login"));
                    gerente.setSenha(rs.getInt("senha"));
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return gerente;
    
    */}

}
