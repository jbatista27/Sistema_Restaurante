/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelo.Gerente;

/**
 *
 * @author João Batista
 */
public class ControlAdmin {
    public boolean cadastrarGarcom(Gerente gerente){
        boolean resultado = false;
        try{
		Conexao conectar = new Conexao(); // Executar conexão com o banco.
		PreparedStatement ps = conectar.getConexao().prepareStatement("INSERT INTO gerente(nome,dataNasc,telefone,endereco,cpf,rg,login,senha,email) VALUES(?,?,?,?,?,?,?,?,?);"); // Prepara uma String para comando SQL Dinâmico.
		ps.setString(1,gerente.getNome()); 
		ps.setString(2,gerente.getDataNasc());
                ps.setString(3,gerente.getTelefone());
                ps.setString(4,gerente.getEndereco());
                ps.setString(5,gerente.getCpf());
		ps.setString(6,gerente.getRg());
                ps.setInt(7,gerente.getLogin());
                ps.setString(8,gerente.getSenha());
                ps.setString(9, gerente.getEmail());
		if(!ps.execute()){ // Executa a SQL * Retorna true quando acontecem erros.
			resultado = true;
		}
	}catch(SQLException e){
		System.out.println(e.getMessage());
	}
        return resultado;
    }
}
