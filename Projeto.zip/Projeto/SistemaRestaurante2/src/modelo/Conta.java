/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author PandaCórnio
 */
public class Conta {
    private String dataAbertura;
    private String horaAbertura;
    private String valorTotal;
    private String estado;
    private String nomeGarcomC;

    public Conta(String dataAbertura, String horaAbertura, String valorTotal, String estado, String nomeGarcomC) {
        this.dataAbertura = dataAbertura;
        this.horaAbertura = horaAbertura;
        this.valorTotal = valorTotal;
        this.estado = estado;
        this.nomeGarcomC = nomeGarcomC;
    }

    
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getNomeGarcomC() {
        return nomeGarcomC;
    }

    public void setNomeGarcomC(String nomeGarcomC) {
        this.nomeGarcomC = nomeGarcomC;
    }

    public String getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public String getHoraAbertura() {
        return horaAbertura;
    }

    public void setHoraAbertura(String horaAbertura) {
        this.horaAbertura = horaAbertura;
    }

    public String getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(String valorTotal) {
        this.valorTotal = valorTotal;
    }
    
    
}
