/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author PandaCórnio
 */
public class Conta {
    private String dataAbertura;
    private String hora;
    private String valorTotal;
    private String estado;
    private String nomeGarcomC;
    private int idConta;

    public Conta(String nomeGarcomC) {
        this.nomeGarcomC = nomeGarcomC;
    }

    public Conta(int idConta) {
        this.idConta = idConta;
    }

    
    public int getIdConta() {
        return idConta;
    }

    public void setIdConta(int idConta) {
        this.idConta = idConta;
    }

    public Conta(String dataAbertura, String hora, String valorTotal, String estado, String nomeGarcomC) {
        this.dataAbertura = dataAbertura;
        this.hora = hora;
        this.valorTotal = valorTotal;
        this.estado = estado;
        this.nomeGarcomC = nomeGarcomC;
    }

    
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getNomeGarcomC() {
        return nomeGarcomC;
    }

    public void setNomeGarcomC(String nomeGarcomC) {
        this.nomeGarcomC = nomeGarcomC;
    }

    public String getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(String valorTotal) {
        this.valorTotal = valorTotal;
    }

    
    
    
}
