/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author PandaCórnio
 */
public class Gerente extends Usuario{
    private String rg;
    private int login;
    private int senha;
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public int getLogin() {
        return login;
    }

    public void setLogin(int login) {
        this.login = login;
    }

    public int getSenha() {
        return senha;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }

    public Gerente(String rg, int login, int senha, String email, String nome, String dataNasc, String telefone, String endereco, String cpf) {
        super(nome, dataNasc, telefone, endereco, cpf);
        this.rg = rg;
        this.login = login;
        this.senha = senha;
        this.email = email;
    }
     
}
