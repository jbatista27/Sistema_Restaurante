/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author João Batista
 */
public class ContaMesa {
   private String nomeGarcom;
   private String valorTotal;
   private String dataAbertura;
   private String hora;
   private int numeroMesa;

    public ContaMesa(String nomeGarcom, String valorTotal, String dataAbertura, String hora, int numeroMesa) {
        this.nomeGarcom = nomeGarcom;
        this.valorTotal = valorTotal;
        this.dataAbertura = dataAbertura;
        this.hora = hora;
        this.numeroMesa = numeroMesa;
    }
   
    public String getNomeGarcom() {
        return nomeGarcom;
    }

    public void setNomeGarcom(String nomeGarcom) {
        this.nomeGarcom = nomeGarcom;
    }

    public String getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(String valorTotal) {
        this.valorTotal = valorTotal;
    }

    public String getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public int getNumeroMesa() {
        return numeroMesa;
    }

    public void setNumeroMesa(int numeroMesa) {
        this.numeroMesa = numeroMesa;
    }
   
    
}
