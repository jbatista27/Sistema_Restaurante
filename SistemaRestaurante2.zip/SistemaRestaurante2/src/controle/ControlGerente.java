/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Conta;
import modelo.Garcom;
import modelo.Produto;

/**
 *
 * @author PandaCórnio
 */
public class ControlGerente {
    Conta conta;
    public boolean cadastrarGarcom(Garcom garcom){
        boolean resultado = false;
        try{
		Conexao conectar = new Conexao(); // Executar conexão com o banco.
		PreparedStatement ps = conectar.getConexao().prepareStatement("INSERT INTO garcom(nome,dataNasc,telefone,endereco,cpf,escolaridade) VALUES(?,?,?,?,?,?);"); // Prepara uma String para comando SQL Dinâmico.
		ps.setString(1,garcom.getNome()); 
		ps.setString(2,garcom.getDataNasc());
                ps.setString(3,garcom.getTelefone());
                ps.setString(4,garcom.getEndereco());
                ps.setString(5,garcom.getCpf());
		ps.setString(6,garcom.getEscolaridade());
		if(!ps.execute()){ // Executa a SQL * Retorna true quando acontecem erros.
			resultado = true;
		}
	}catch(SQLException e){
		System.out.println(e.getMessage());
	}
        return resultado;
    }
    
    public boolean cadastrarProdutos(Produto produto){
        boolean resultado = false;
        try {
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getConexao().prepareStatement("INSERT INTO produto(nome,porcao,valor,categoria,quantidade) VALUES(?,?,?,?,?);");
            ps.setString(1,produto.getNome());
            ps.setString(2,produto.getPocao());
            ps.setFloat(3,produto.getValor());
            ps.setString(4,produto.getCategoria());
            ps.setInt(5,produto.getQuantEstoque());
            if(!ps.execute()){ // Executa a SQL * Retorna true quando acontecem erros.
			resultado = true;
		}
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return resultado;
    }
    
    //Editar Produto
    public boolean editarProduto(Produto produto, Produto produto1){
        boolean resultado = false;
        try {
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getConexao().prepareStatement("UPDATE produto SET nome=?, porcao=?, valor=?, categoria=?, quantidade=?  WHERE idProduto=?;");
            ps.setString(1,produto.getNome());
            ps.setString(2,produto.getPocao());
            ps.setFloat(3,produto.getValor());
            ps.setString(4,produto.getCategoria());
            ps.setInt(5,produto.getQuantEstoque());
            ps.setInt(6,produto1.getId());
            if(!ps.execute()){ // Executa a SQL * Retorna true quando acontecem erros.
			resultado = true;
		}
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return resultado;
    }
    
    //Deletar Produto
    public boolean deleteProduto(Produto produto){
        boolean resultado = false;
        try{
            Conexao conectar = new Conexao(); // Executar conexão com o banco.
            PreparedStatement ps = conectar.getConexao().prepareStatement("DELETE FROM produto WHERE idProduto=?;"); 
            ps.setInt(1, produto.getId());
            if(ps.execute()){
                return true;
            } 
	}catch(SQLException e){
            System.out.println(e.getMessage());
	}
        return resultado;
    }
    public String calcularComissoes(){
        return null;
    }
    
    public String gerarOcupacaoMesas(){
        return null;
    }
    public ArrayList consultarProdutos(){
        // Código para consultar todas as tuplas
        ArrayList lista = new ArrayList<>();
        //lista =null;
        try{
            Conexao conectar = new Conexao(); // Abre a conexão com o banco
            PreparedStatement ps = conectar.getConexao().prepareStatement("SELECT * FROM produto;"); // Definir o comando que será executado
            ResultSet rs = ps.executeQuery(); // Armazena os dados no Objeto ResultSet
        if(rs != null){ // Verifica se o resultado é nulo
            while(rs.next()){ // Enquanto existir tuplas na consulta       
                        String nome, categoria,pocao;
                        int quantEstoque,id;
                        float valor;
                        
                        id = rs.getInt("idProduto");
                        nome = rs.getString("nome");
                        pocao = rs.getString("porcao");
                        categoria = rs.getString("categoria");
                        quantEstoque = rs.getInt("quantidade");
                        valor = rs.getFloat("valor");
                        
                        Produto li = new Produto(nome, pocao, valor, categoria, quantEstoque);
                        Produto li2 = new Produto(id);
                    	li.setNome(nome);
                        li.setPocao(pocao);
                        li.setValor(valor);
                        li.setCategoria(categoria);
                        li.setQuantEstoque(quantEstoque);
                        li.setId(id);
                       
                        lista.add(li);
                        lista.add(li2);
            }
	}else{
            lista=null;
        }
	}catch(SQLException e){
		lista = null;
	}
        return lista;
    }
    public Produto consultarProdutos(String categoria){
        // Código para consultar uma única tupla
        Produto produto = null;
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getConexao().prepareStatement("SELECT * FROM produto WHERE categoria = ?;");
            ps.setString(1, categoria);
            ResultSet rs = ps.executeQuery();
            if(rs != null){
                while(rs.next()){
                        String nome, categoria2, pocao;
                        int quantEstoque,id;
                        float valor;
                        
                        id = rs.getInt("idProduto");
                        nome = rs.getString("nome");
                        pocao = rs.getString("porcao");
                        categoria2 = rs.getString("categoria");
                        quantEstoque = rs.getInt("quantidade");
                        valor = rs.getFloat("valor");
                        
                        produto = new Produto(nome, pocao, valor, categoria2, quantEstoque);
                        produto = new Produto(id);
                    	produto.setNome(nome);
                        produto.setPocao(pocao);
                        produto.setValor(valor);
                        produto.setCategoria(categoria2);
                        produto.setQuantEstoque(quantEstoque);
                        produto.setId(id);
        		
                }
            }
        }catch(SQLException e){
              System.out.println(e.getMessage());
	}			
	return produto;
    }
    public Produto consultarProdutos2(String nome){
        // Código para consultar uma única tupla
        Produto produto = null;
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getConexao().prepareStatement("SELECT * FROM produto WHERE nome = ?;");
            ps.setString(1, nome);
            ResultSet rs = ps.executeQuery();
            if(rs != null){
                while(rs.next()){
                        String nome2, categoria, pocao;
                        int quantEstoque, id;
                        float valor;
                        
                        id = rs.getInt("idProduto");
                        nome2 = rs.getString("nome");
                        pocao = rs.getString("porcao");
                        categoria = rs.getString("categoria");
                        quantEstoque = rs.getInt("quantidade");
                        valor = rs.getFloat("valor");
                        
                        produto = new Produto(nome2, pocao, valor, categoria, quantEstoque);
                        produto = new Produto(id);
                    	produto.setNome(nome2);
                        produto.setPocao(pocao);
                        produto.setValor(valor);
                        produto.setCategoria(categoria);
                        produto.setQuantEstoque(quantEstoque);
                        produto.setId(id);
        		
                }
            }
        }catch(SQLException e){
              System.out.println(e.getMessage());
	}			
	return produto;
    }
}
