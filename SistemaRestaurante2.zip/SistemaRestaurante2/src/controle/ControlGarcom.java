/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;
import modelo.Conta;
import modelo.Garcom;

/**
 *
 * @author PandaCórnio
 */
public class ControlGarcom {
    Garcom garcom;
    Conta conta;
    public String abrirConta(){
        return null;
    }
    
    public String associarProdutoConta(){
        return null;
    }
    
    public String cancelarConta(){
        return null;
    }
    
    public String fecharConta(){
        return null;
    }
    
    public String excluirPedido(){
        return null;
    }
}
