/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Paulo
 */
public class Mesas {
    private int numeroMesa;
    private int idMesaGarcom;
    private int idProdutoM;

    public Mesas(int numeroMesa, int idMesaGarcom, int idProdutoM) {
        this.numeroMesa = numeroMesa;
        this.idMesaGarcom = idMesaGarcom;
        this.idProdutoM = idProdutoM;
    }

    public int getIdProdutoM() {
        return idProdutoM;
    }

    public void setIdProdutoM(int idProdutoM) {
        this.idProdutoM = idProdutoM;
    }

    public int getNumeroMesa() {
        return numeroMesa;
    }

    public void setNumeroMesa(int numeroMesa) {
        this.numeroMesa = numeroMesa;
    }

    public int getIdMesaGarcom() {
        return idMesaGarcom;
    }

    public void setIdMesaGarcom(int idMesaGarcom) {
        this.idMesaGarcom = idMesaGarcom;
    }
    
    
    
}
