/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author PandaCórnio
 */
public class Garcom extends Usuario{
    private String escolaridade;

    public String getEscolaridade() {
        return escolaridade;
    }

    public void setEscolaridade(String escolaridade) {
        this.escolaridade = escolaridade;
    }

    public Garcom(String escolaridade, String nome, String dataNasc, String telefone, String endereco, String cpf) {
        super(nome, dataNasc, telefone, endereco, cpf);
        this.escolaridade = escolaridade;
    }
    
}
