/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author PandaCórnio
 */
public class Conta {
    private String codCarcom;
    private String dataAbertura;
    private String horaAbertura;
    private int valorTotal;
    private Produto[] produtos;

    public Conta(String codCarcom, String dataAbertura, String horaAbertura, int valorTotal, Produto[] produtos) {
        this.codCarcom = codCarcom;
        this.dataAbertura = dataAbertura;
        this.horaAbertura = horaAbertura;
        this.valorTotal = valorTotal;
        this.produtos = produtos;
    }
   
    public Produto[] getProdutos() {
        return produtos;
    }

    public void setProdutos(Produto[] produtos) {
        this.produtos = produtos;
    }

    public String getCodCarcom() {
        return codCarcom;
    }

    public void setCodCarcom(String codCarcom) {
        this.codCarcom = codCarcom;
    }

    public String getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public String getHoraAbertura() {
        return horaAbertura;
    }

    public void setHoraAbertura(String horaAbertura) {
        this.horaAbertura = horaAbertura;
    }

    public int getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(int valorTotal) {
        this.valorTotal = valorTotal;
    }
    
    
}
