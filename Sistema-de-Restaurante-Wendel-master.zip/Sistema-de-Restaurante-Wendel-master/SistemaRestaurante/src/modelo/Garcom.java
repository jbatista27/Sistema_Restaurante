/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author PandaCórnio
 */
public class Garcom extends Usuario{
    private String escolaridade;
    private String senha;
    private int codgarcom;

    /**
     *
     */
   

    public void setCodgarcom(int codgarcom) {
        this.codgarcom = codgarcom;
    }

    public int getCodgarcom() {
        return codgarcom;
    }

    
    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getEscolaridade() {
        return escolaridade;
    }

    public void setEscolaridade(String escolaridade) {
        this.escolaridade = escolaridade;
    }

    public Garcom(String escolaridade, String senha, String nome, String dataNasc, String telefone, String endereco, String cpf) {
        super(nome, dataNasc, telefone, endereco, cpf);
        this.escolaridade = escolaridade;
        this.senha = senha;
    }

   
    
}
