/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author PandaCórnio
 */
public class Produto {
    private int id;
    private String nome;
    private String pocao;
    public float valor;
    private String categoria;
    private int quantEstoque;

    public Produto(int id) {
        this.id = id;
    }

    public Produto(String nome, float valor, int id) {
        this.nome = nome;
        this.id = id;
        this.valor = valor;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Produto(String nome, String pocao, float valor, String categoria, int quantEstoque) {
        this.nome = nome;
        this.pocao = pocao;
        this.valor = valor;
        this.categoria = categoria;
        this.quantEstoque = quantEstoque;
    }

   
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPocao() {
        return pocao;
    }

    public void setPocao(String pocao) {
        this.pocao = pocao;
    }

    public Float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getQuantEstoque() {
        return quantEstoque;
    }

    public void setQuantEstoque(int quantEstoque) {
        this.quantEstoque = quantEstoque;
    }
    
    
}
