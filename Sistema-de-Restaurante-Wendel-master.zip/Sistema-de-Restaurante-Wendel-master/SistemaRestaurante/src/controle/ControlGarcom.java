/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Conta;
import modelo.ContaMesa;
import modelo.Garcom;
import modelo.Mesas;
import modelo.Produto;

/**
 *
 * @author PandaCórnio
 */
public class ControlGarcom {
    Garcom garcom;
    Conta conta;
    public boolean cadastrarMesa(Mesas mesas){
        boolean resultado = false;
        try{
		Conexao conectar = new Conexao(); // Executar conexão com o banco.
		PreparedStatement ps = conectar.getConexao().prepareStatement("INSERT INTO mesa (numeroMesa,idGarcomM,idProduto) VALUES(?,?,?);"); // Prepara uma String para comando SQL Dinâmico.
		ps.setInt(1,mesas.getNumeroMesa()); 
		ps.setInt(2,mesas.getIdMesaGarcom());
                ps.setInt(3,mesas.getIdProdutoM());
		if(!ps.execute()){ // Executa a SQL * Retorna true quando acontecem erros.
			resultado = true;
		}
	}catch(SQLException e){
		System.out.println(e.getMessage());
	}
        return resultado;
    }
    public boolean abrirConta(Conta conta){
        boolean resultado = false;
        try {
            Conexao con = new Conexao();
            PreparedStatement ps = con.getConexao().prepareStatement("INSERT INTO conta(nomeGarcom,dataAbertura,hora,valorTotal,estado) VALUES(?,?,?,?,?);");
            ps.setString(1, conta.getNomeGarcomC());
            ps.setString(2, conta.getDataAbertura());
            ps.setString(3, conta.getHora());
            ps.setString(4, conta.getValorTotal());
            ps.setString(5, conta.getEstado());
               if (!ps.execute()) {
                   resultado = true;
               }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return resultado;
    }
    public String associarProdutoConta(){
        return null;
    }
    
    public String cancelarConta(){
        return null;
    }
    
    public boolean fecharConta(Conta conta){
        boolean resultado = false;
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getConexao().prepareStatement("UPDATE conta SET estado=0 WHERE  mesa = ?;");
            ps.setString(1, conta.getNomeGarcomC());
            if(!ps.execute()){
                resultado = true;
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return resultado;
        
    }
    
    public boolean excluirPedido(Conta conta){
        boolean resultado = false;
        try {
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getConexao().prepareStatement("DELETE FROM conta WHERE nomeGarcom = ?;");
            ps.setString(1, conta.getNomeGarcomC());
            if(!ps.execute()){
                resultado = true;
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return resultado;
    }
     public boolean excluirMesa(Mesas mesas){
        boolean resultado = false;
        try {
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getConexao().prepareStatement("DELETE FROM mesa WHERE idGarcomM = ?;");
            ps.setInt(1, mesas.getIdGarcomM());
            if(!ps.execute()){
                resultado = true;
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return resultado;
    }
      public boolean checkLogin(String cpf, String senha) {

        Connection con = Conexao.getConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        boolean check = false;

        try {

            stmt = con.prepareStatement("SELECT * FROM garcom WHERE cpf = ? and senha = ?;");
            stmt.setString(1, cpf);
            stmt.setString(2, senha);

            rs = stmt.executeQuery();

            if (rs.next()) {
                check = true;
                Sessao sessao = new Sessao();
                sessao.setId(rs.getInt("codGarcom"));
                sessao.setNome(rs.getString("nome"));
            }

        } catch (SQLException ex) {
            Logger.getLogger(ControlGarcom.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            Conexao.closeConexao();
        }

        return check;

    }
    public ArrayList consultarProdutos(){
        // Código para consultar todas as tuplas
        ArrayList lista = new ArrayList<>();
        //lista =null;
        try{
            Conexao conectar = new Conexao(); // Abre a conexão com o banco
            PreparedStatement ps = conectar.getConexao().prepareStatement("SELECT * FROM produto;"); // Definir o comando que será executado
            ResultSet rs = ps.executeQuery(); // Armazena os dados no Objeto ResultSet
        if(rs != null){ // Verifica se o resultado é nulo
            while(rs.next()){ // Enquanto existir tuplas na consulta       
                        String nome;                       
                        float valor;
                        int id;
                        
                        nome = rs.getString("nome");
                        valor = rs.getFloat("valor");
                        id = rs.getInt("idProduto");
                        
                        Produto li = new Produto(nome, valor,id);                      
                    	li.setNome(nome);                       
                        li.setValor(valor);
                        li.setId(id);
                                              
                        lista.add(li);
                       
            }
	}else{
            lista=null;
        }
	}catch(SQLException e){
		lista = null;
	}
        return lista;
    }
    public ArrayList consultar(){
        // Código para consultar todas as tuplas
        ArrayList lista = new ArrayList<>();
        //lista =null;
        try{
            Conexao conectar = new Conexao(); // Abre a conexão com o banco
            PreparedStatement ps = conectar.getConexao().prepareStatement("SELECT conta.nomeGarcom, conta.dataAbertura, conta.hora, conta.valorTotal, mesa.numeroMesa FROM mesa INNER JOIN conta;"); // Definir o comando que será executado
            ResultSet rs = ps.executeQuery(); // Armazena os dados no Objeto ResultSet
        if(rs != null){ // Verifica se o resultado é nulo
            while(rs.next()){ // Enquanto existir tuplas na consulta       
                        String nome, valorTotal, data, hora, pedidos;
                        int numeroMesa;
                        
                        nome = rs.getString("nomeGarcom");
                        valorTotal = rs.getString("valorTotal");
                        data = rs.getString("dataAbertura");
                        hora = rs.getString("hora");                        
                        numeroMesa = rs.getInt("numeroMesa");
                       
                        ContaMesa li = new ContaMesa(nome, valorTotal, data, hora, numeroMesa);
                        li.setDataAbertura(data);
                        li.setHora(hora);
                        li.setNomeGarcom(nome);
                        li.setNumeroMesa(numeroMesa);
                        li.setValorTotal(valorTotal);                                            
                        lista.add(li);
                       
            }
	}else{
            lista=null;
        }
	}catch(SQLException e){
		lista = null;
	}
        return lista;
    }
    

public Sessao consultarGarcom(String cpf){
        Sessao sessao = null;
        try{
            Conexao conectar = new Conexao();
            PreparedStatement ps = conectar.getConexao().prepareStatement("SELECT * FROM garcom WHERE cpf =?;"); 
            ps.setString(1, cpf);
            ResultSet rs = ps.executeQuery();
                        if(rs != null){
                            while(rs.next()){
				sessao = new Sessao();
                                sessao.setNome(rs.getString("nome"));
                    		sessao.setId(rs.getInt("codGarcom"));
                    		  
                            }
			}
        }catch(SQLException e){
            System.out.println(e.getMessage());
	}			  
        return sessao;
    }
}