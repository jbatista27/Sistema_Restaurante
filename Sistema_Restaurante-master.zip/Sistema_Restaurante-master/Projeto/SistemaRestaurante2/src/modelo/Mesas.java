/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Paulo
 */
public class Mesas {
    private int numeroMesa;
    private int idMesaGarcom;
    private int idProdutoM;
    private int idGarcomM;

    public int getIdGarcomM() {
        return idGarcomM;
    }

    public void setIdGarcomM(int idGarcomM) {
        this.idGarcomM = idGarcomM;
    }

    public Mesas(int idGarcomM) {
        this.idGarcomM = idGarcomM;
    }

    public Mesas(int numeroMesa, int idMesaGarcom, int idProdutoM, int idGarcomM) {
        this.numeroMesa = numeroMesa;
        this.idMesaGarcom = idMesaGarcom;
        this.idProdutoM = idProdutoM;
        this.idGarcomM = idGarcomM;
    }

   

    public int getIdProdutoM() {
        return idProdutoM;
    }

    public void setIdProdutoM(int idProdutoM) {
        this.idProdutoM = idProdutoM;
    }

    public int getNumeroMesa() {
        return numeroMesa;
    }

    public void setNumeroMesa(int numeroMesa) {
        this.numeroMesa = numeroMesa;
    }

    public int getIdMesaGarcom() {
        return idMesaGarcom;
    }

    public void setIdMesaGarcom(int idMesaGarcom) {
        this.idMesaGarcom = idMesaGarcom;
    }
    
    
    
}
